# Alhadi CMMS — نسخة نهائية للتثبيت الداخلي

هذه الحزمة تضيف بناء Release APK موقّع للتوزيع الداخلي على أجهزة Android.

## النتيجة

بعد تشغيل Workflow ستحصل على Artifact باسم:

`Alhadi-CMMS-internal-release-apk`

وبداخله:

`app-release.apk`

هذا هو ملف التثبيت الداخلي النهائي.

## الملفات المضافة

- `.github/workflows/build-internal-release-from-zip.yml`
  - مناسب إذا كان المستودع يبني من ملف ZIP مرفوع باسم `alhadi-cmms-apk-github.zip`.
- `.github/workflows/build-internal-release.yml`
  - مناسب إذا كانت ملفات المشروع مفكوكة داخل المستودع مباشرة.
- `.github/workflows/generate-release-keystore.yml`
  - لإنشاء مفتاح توقيع ثابت وإخراج قيم GitHub Secrets.

## وضعان للبناء

### 1) بناء سريع بدون Secrets

شغّل Workflow:

`Build Internal Release APK from ZIP`

إذا لم يجد أسرار التوقيع، سيولّد مفتاحًا مؤقتًا ويخرج APK موقّعًا.

هذا APK يعمل للتثبيت الداخلي، لكن إذا بنيت نسخة مستقبلية بمفتاح مختلف قد لا تثبت فوق النسخة القديمة، وقد تحتاج حذف التطبيق ثم تثبيته من جديد.

### 2) بناء نهائي ثابت للتحديثات

الأفضل أن تضيف هذه الأسرار في GitHub:

- `CMMS_KEYSTORE_BASE64`
- `CMMS_KEYSTORE_PASSWORD`
- `CMMS_KEY_ALIAS`
- `CMMS_KEY_PASSWORD`

بعدها كل إصدار جديد سيستخدم نفس التوقيع، ويمكن تثبيته كتحديث فوق النسخة السابقة.

## طريقة إنشاء أسرار التوقيع من الهاتف

1. افتح GitHub → Actions.
2. شغّل Workflow باسم `Generate CMMS Release Keystore`.
3. بعد النجاح، حمّل Artifact باسم `CMMS-release-keystore-private-save`.
4. افتح الملف `GITHUB_SECRETS_TO_ADD.txt`.
5. أضف كل قيمة في:
   `Repository → Settings → Secrets and variables → Actions → New repository secret`

## أسرار Firebase الاختيارية

يمكنك أيضًا جعل Firebase Config مدمجًا في APK النهائي بدل لصقه من داخل التطبيق بإضافة الأسرار التالية:

- `VITE_FIREBASE_API_KEY`
- `VITE_FIREBASE_AUTH_DOMAIN`
- `VITE_FIREBASE_PROJECT_ID`
- `VITE_FIREBASE_STORAGE_BUCKET`
- `VITE_FIREBASE_MESSAGING_SENDER_ID`
- `VITE_FIREBASE_APP_ID`
- `VITE_FIREBASE_OWNER_EMAIL`

إذا لم تضفها، سيبقى التطبيق يقبل لصق Firebase Config من شاشة `Firebase والصلاحيات`.

## رفع النسخة الجديدة

ارفع الملف:

`alhadi-cmms-apk-github.zip`

بنفس الاسم القديم، ثم شغّل:

`Actions → Build Internal Release APK from ZIP → Run workflow`

## ملاحظات مهمة

- احتفظ بملف keystore والأسرار في مكان آمن.
- لا ترفع ملف keystore داخل المستودع.
- لا تغيّر Package ID بعد بدء التوزيع الداخلي.
- زِد `version_code` مع كل إصدار جديد، مثل 1 ثم 2 ثم 3.
